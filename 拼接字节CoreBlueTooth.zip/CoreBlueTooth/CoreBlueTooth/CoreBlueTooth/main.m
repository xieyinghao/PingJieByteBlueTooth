//
//  main.m
//  CoreBlueTooth
//
//  Created by YG on 15/3/11.
//  Copyright (c) 2015年 YG. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "QFAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([QFAppDelegate class]));
    }
}

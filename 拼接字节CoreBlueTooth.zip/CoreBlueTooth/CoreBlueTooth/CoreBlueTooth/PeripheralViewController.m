//
//  PeripheralViewController.m
//  CoreBlueToothDemo
//
//  Created by YG on 15/2/3.
//  Copyright (c) 2015年 YG. All rights reserved.
//

#import "PeripheralViewController.h"

//导入蓝牙所需的头文件CoreBluetooth
#import <CoreBluetooth/CoreBluetooth.h>

//导入配置文件的头文件
#import "BlueToothHeader.h"

@interface PeripheralViewController ()<CBPeripheralManagerDelegate>
{
    UILabel * _statusLb;
    UITextField * _inputView;
    
    // 保存当前发送了多少字节（因为每次最多发20个字节，数据较大时，需要多次发送，每次发送完需要记录已经发送了多少个字节了，以便下一次继续接着发送）
    unsigned long _sendBytes;
    
    // 是否发送完成
    BOOL _finish;
    
}

// 周边设备管理类
@property(nonatomic,strong)CBPeripheralManager *peripheralManager;

// 可变服务特性
@property(nonatomic,strong)CBMutableCharacteristic *myCharacteristic;

@end

@implementation PeripheralViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    _statusLb = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 30)];
    _statusLb.text = @"发送广播中...";
    [self.view addSubview:_statusLb];
    
    _inputView = [[UITextField alloc] initWithFrame:CGRectMake(0, 30, 270, 30)];
    _inputView.placeholder = @"需要通过蓝牙发送的消息...";
    [self.view addSubview:_inputView];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setFrame:CGRectMake(270, 30, 50, 30)];
    [button setBackgroundColor:[UIColor grayColor]];
    [button setTitle:@"发送" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(sendDataClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    
    
    
#pragma  mark - 1、创建周边设备管理器
    self.peripheralManager = [[CBPeripheralManager alloc] initWithDelegate:self queue:nil];

}


#pragma mark - CBPeripheralManagerDelegate
#pragma  mark - 检查蓝牙状态(是否打开)
-(void)peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral
{
    if (peripheral.state != CBPeripheralManagerStatePoweredOn) {
        NSLog(@"蓝牙关闭");
        return;
    }
    
    
#pragma  mark - 2、初始化服务并启动
    
    // 1、 创建特征
    /*
     properties：CBCharacteristicPropertyNotify 允许通过特征发送数据时没有响应（回答）
     permissions：read属性为只读权限
    */
    self.myCharacteristic = [[CBMutableCharacteristic alloc] initWithType:[CBUUID UUIDWithString:CHARACTERISTIC_UUID] properties:CBCharacteristicPropertyNotify value:nil permissions:CBAttributePermissionsReadable];
    
    //2、 创建服务
    /* 
     primary： YES主要的， NO次要的
     */
    CBMutableService *myService = [[CBMutableService alloc] initWithType:[CBUUID UUIDWithString:SERVICE_UUID] primary:YES];
    
    
    //3、 给服务myService添加特征
    myService.characteristics = @[self.myCharacteristic];
    
    //4、 把服务添加到周边管理器（Peripheral Manager）用于发布服务
    [self.peripheralManager addService:myService];
    
    //5、 发送广播，服务UUID是SERVICE_UUID：让中央设备可以扫描到该服务
    [self.peripheralManager startAdvertising:@{CBAdvertisementDataServiceUUIDsKey:@[[CBUUID UUIDWithString:SERVICE_UUID]]}];
    
}

#pragma  mark - 回调方法 订阅特性成功 开始发送数据
-(void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didSubscribeToCharacteristic:(CBCharacteristic *)characteristic
{
    //订阅:订阅特征
    NSLog(@"订阅成功");
    _statusLb.text = @"订阅成功 可以发送消息了";
}

#pragma  mark - 回调方法  中央设备结束订阅时候调用
-(void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didUnsubscribeFromCharacteristic:(CBCharacteristic *)characteristic
{
    NSLog(@"结束订阅");
    _statusLb.text = @"订阅结束";
}


#pragma  mark - 发送数据
- (void)sendDataClick
{
    //结束发送
    if ( _finish ) {
        
        //发送结束标识符，表示发送结束
        NSData *endData = [BLUETOOTH_TEXT_END dataUsingEncoding:NSUTF8StringEncoding];
        BOOL didSend = [self.peripheralManager updateValue:endData forCharacteristic:self.myCharacteristic onSubscribedCentrals:nil];
        
        //发送结束标识符成功。
        if ( didSend ) {
            
            _finish = NO;
            _sendBytes = 0;
            NSLog(@"发送完成");
        }
        
        return;
    }
    
    
    // 发送文字
    NSData * sendData = [_inputView.text dataUsingEncoding:NSUTF8StringEncoding];
    
#if 0
    // 发送图片
    NSData * sendData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"1" ofType:@"png"]];
#endif

    
    //如果数据已经发送完了
    if ( sendData.length <= _sendBytes ) {
        //没有数据，退出即可
        return;
    }
    
    
    //如果有数据没有发送完
    BOOL didSend = YES;
    
    while (didSend) {
        
        //1001  发前面20b
        // 981  从20的位置开始发送20b
        // 961  从40的位置开始发送20b
        // ...
        // 21   从980的位置开始发送20b
        // 1    从1000的位置发送1b
        
        //计算出剩余数据的大小
        NSInteger amountToSend = sendData.length - _sendBytes;
        
        //如果剩余的数据大于20字节，那就传送20字节（蓝牙一次最多传输20byte）
        if (amountToSend > MAX_BYTES) {
            amountToSend = MAX_BYTES;
        }
        
        //计算出发送的数据内容，从sendData.bytes+_sendBytes开始，长度为amountToSend（ sendData.bytes表示数据的首地址）
        NSData *oneData = [NSData dataWithBytes:sendData.bytes+_sendBytes length:amountToSend];
        
#pragma  mark - 7、发送数据给中央设备
        //发送数据
        didSend = [self.peripheralManager updateValue:oneData forCharacteristic:self.myCharacteristic onSubscribedCentrals:nil];
        
        //如果没发送成功
        if (!didSend) {
            return;
        }
        else {
            
            _sendBytes += amountToSend;
            
            //判断是否发送完
            if (_sendBytes >= sendData.length) {
                
                //发送完成，最后再发送结束标示BLUETOOTH_TEXT_END，告诉中央设备，该数据已经全部发送了
                _finish = YES;
                [self performSelector:@selector(sendDataClick) withObject:nil afterDelay:0.1];
            }
        }
        
    }
    
    
    [self.view endEditing:YES];
}



// 发送队列满了 需要再次发送
-(void)peripheralManagerIsReadyToUpdateSubscribers:(CBPeripheralManager *)peripheral
{
    // NSLog(@"发送队列已满 再次发送");
    [self sendDataClick];
}


@end





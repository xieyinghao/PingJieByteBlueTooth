//
//  QFAppDelegate.h
//  CoreBlueTooth
//
//  Created by YG on 15/3/11.
//  Copyright (c) 2015年 YG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QFAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

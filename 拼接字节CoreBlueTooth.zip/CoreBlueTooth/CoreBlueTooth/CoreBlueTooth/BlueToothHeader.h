//
//  BlueToothHeader.h
//  CoreBlueToothDemo
//
//  Created by YG on 15/2/3.
//  Copyright (c) 2015年 YG. All rights reserved.
//

#ifndef CoreBlueToothDemo_BlueToothHeader_h
#define CoreBlueToothDemo_BlueToothHeader_h

//服务的UUID
#define SERVICE_UUID        @"307846BD-EDB4-4E3B-A0A7-52B2E5AFA760" //自定义

//特征的UUID
#define CHARACTERISTIC_UUID @"C430B109-A222-44A9-B75D-49D89BD97642" //自定义

//标志结束符
#define BLUETOOTH_TEXT_END  @"TEXT_END" //自定义

//最大传输字节数
#define MAX_BYTES 20


#endif

//
//  CentralViewController.m
//  CoreBlueToothDemo
//
//  Created by YG on 15/2/3.
//  Copyright (c) 2015年 YG. All rights reserved.
//

#import "CentralViewController.h"

//导入蓝牙所需的头文件CoreBluetooth
#import <CoreBluetooth/CoreBluetooth.h>

//导入配置文件的头文件
#import "BlueToothHeader.h"


@interface CentralViewController ()<CBCentralManagerDelegate,CBPeripheralDelegate>
{
    CBCentralManager *_manager;
    
    UILabel *_statusLb;
    UILabel *_showLb;
}

@property (nonatomic,strong) CBPeripheral *discovedPeripheral;
@property (nonatomic,strong) NSMutableData *data;

@end

@implementation CentralViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //初始化数据
    _data = [NSMutableData data];

#pragma  mark - 1、创建中央设备管理器
    _manager = [[CBCentralManager alloc] initWithDelegate:self queue:dispatch_get_main_queue()];
    
    
    //连接状态Label
    _statusLb = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 30)];
    _statusLb.text = @"扫描外设中...";
    [self.view addSubview:_statusLb];
    
    //显示接收到外围设备发送过来的数据
    _showLb = [[UILabel alloc] initWithFrame:CGRectMake(0, 30, 320, 100)];
    _showLb.numberOfLines = 0;
    _showLb.text = @"接受到的数据:";
    [self.view addSubview:_showLb];
    
}


#pragma  mark - 清空连接
-(void)clearUp{
    
//    if (![self.discovedPeripheral isConnected]) {
//        return;
//    }
    
    if (self.discovedPeripheral.services != nil) {
        for (CBService *server in self.discovedPeripheral.services) {
            
            if (server.characteristics != nil) {
                for (CBCharacteristic *chatacter in server.characteristics) {
                    
                    if ([chatacter.UUID isEqual:[CBUUID UUIDWithString:CHARACTERISTIC_UUID]]) {
                        
                        // 是否订阅
                        if (chatacter.isNotifying) {
                            // 如果订阅 取消订阅
                            [self.discovedPeripheral setNotifyValue:NO forCharacteristic:chatacter];
                            return;
                        }
                        
                    }
                    
                }
            }
        }
    }
    
    // 连接了， 但没有订阅, 断开连接
    [_manager cancelPeripheralConnection:self.discovedPeripheral];
    
}

#pragma mark - CBCentralManagerDelegate
// 检测中央设备状态
-(void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    if (central.state != CBCentralManagerStatePoweredOn) {
        NSLog(@"蓝牙关闭");
        return;
    }
    
    // 开启扫描
    [self scan];
}

#pragma mark - 2、扫描周边设备
-(void)scan{
    
    // CBCentralManagerScanOptionAllowDuplicatesKey：是否允许多次扫描同一个外围设备
    [_manager scanForPeripheralsWithServices:@[[CBUUID UUIDWithString:SERVICE_UUID]] options:@{ CBCentralManagerScanOptionAllowDuplicatesKey : @YES }];
}


#pragma  mark - 回调方法 成功扫描到周边设备
/*
 peripheral：扫描到的周边设备
 advertisementData：响应数据
 RSSI即Received Signal Strength Indication：接收的信号强度指示
 */
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI
{
    
    // 判断是不是我们已经监听到了的外围设备
    if (self.discovedPeripheral != peripheral) {
        self.discovedPeripheral = peripheral;
        
#pragma  mark - 3、连接周边设备
        [_manager connectPeripheral:peripheral options:nil];

    }
}

#pragma  mark - 回调方法 成功连接周边设备
-(void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    // 连接完成后，就停止扫描
    [_manager stopScan];
    
    //清空数据
    [self.data setLength:0];
    
    // 设置代理
    peripheral.delegate = self;
    
#pragma  mark - 4、扫描周边设备的服务
    [peripheral discoverServices:@[[CBUUID UUIDWithString:SERVICE_UUID]]];
    
}

#pragma  mark - 回调方法 接收到了连接的周边设备的服务
-(void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
    
    if (error) {
        NSLog(@"error: %@", error);
        [self clearUp];
        return;
    }
    
    // 找到我们想要的特性
    // 遍历外围设备
    for (CBService *server in peripheral.services) {
        
#pragma mark - 5、扫描周边设备指定的特征
        [peripheral discoverCharacteristics:@[[CBUUID UUIDWithString:CHARACTERISTIC_UUID]] forService:server];
    }
}

#pragma  mark - 回调方法 获取特征
-(void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error
{
    if (error) {
        NSLog(@"error: %@", error);
        [self clearUp];
        return;
    }
    
    // 检查特性
    for (CBCharacteristic *characteristic in service.characteristics) {
        
        if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:CHARACTERISTIC_UUID]]) {
            
            //找到我们想要的特征后，则通过订阅该特征来获取数据
            //开启订阅(开启监听数据)

#pragma mark - 6、开启订阅(监听数据)
            [peripheral setNotifyValue:YES forCharacteristic:characteristic];

        }
    }
}

#pragma  mark - 回调方法 接收到数据
-(void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    if (error) {
        NSLog(@"error: %@", error);
        return;
    }
    
    // characteristic.value 是特性中所包含的数据，也就是外围设备发送给我们的数据
    NSString * receiveString = [[NSString alloc]initWithData:characteristic.value encoding:NSUTF8StringEncoding];

    //如果还没有接收完全，则继续接收（如果数据较大，则要接收很多次才能保证接收完全）
    if ( ![receiveString isEqualToString:BLUETOOTH_TEXT_END]) {
        
        // 数据没有传递完成，继续传递数据
        [self.data appendData:characteristic.value];

    }
    
    //停止接收
    else{
        
        // 将接收的文字显示
        NSString * str = [[NSString alloc] initWithData:self.data encoding:NSUTF8StringEncoding];
        _showLb.text = str;
        
        self.data.length = 0;
        
#if 0
        // 将接收到的图片显示
        UIImage * img = [UIImage imageWithData:self.data];
        UIImageView * imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 150, 320, 200)];
        imgView.image = img;
        [self.view addSubview:imgView];
#endif
        
#if 0
        // 取消订阅 断开蓝牙连接
        [peripheral setNotifyValue:NO forCharacteristic:characteristic];
        
        [_manager cancelPeripheralConnection:peripheral];
#endif

    }
    
}


#pragma  mark - 监听订阅状态
-(void)peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    if (error) {
        NSLog(@"error: %@", error);
        return;
    }
    
    // 如果不是我们要的特性就返回
    if (![characteristic.UUID isEqual:[CBUUID UUIDWithString:CHARACTERISTIC_UUID]]) {
        return;
    }
    
    
    //订阅开启了
    if (characteristic.isNotifying) {
        
        NSLog(@"外围设备开启订阅了");
        _statusLb.text = @"连接成功，等待接受数据";
        
    }
    
    //订阅取消了
    else{
        
        NSLog(@"外围设备关闭订阅了");
        // 断开连接
        [_manager cancelPeripheralConnection:peripheral];
        
    }
}


@end

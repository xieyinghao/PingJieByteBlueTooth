//
//  ViewController.m
//  CoreBlueToothDemo
//
//  Created by YG on 15/2/3.
//  Copyright (c) 2015年 YG. All rights reserved.
//

#import "ViewController.h"
#import "CentralViewController.h"
#import "PeripheralViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSArray * arr = @[@"创建中心",@"创建外设"];
    
    for (int i = 0; i < 2; i++) {
        
        UIButton * b = [UIButton buttonWithType:UIButtonTypeSystem];
        [b setFrame:CGRectMake(100, 50+50*i, 100, 30)];
        [b setTag:10+i];
        [b setBackgroundColor:[UIColor grayColor]];
        [b setTitle:arr[i] forState:UIControlStateNormal];
        [b setTitleColor:[UIColor whiteColor] forState:0];
        [b addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
        
        [self.view addSubview:b];
    }
}

- (void)click:(UIButton *)b
{
    if (b.tag == 10) {
        CentralViewController * ctl = [[CentralViewController alloc] init];
        [self.navigationController pushViewController:ctl animated:YES];
    }else{
        PeripheralViewController * ctl = [[PeripheralViewController alloc] init];
        [self.navigationController pushViewController:ctl animated:YES];
    }
}

@end

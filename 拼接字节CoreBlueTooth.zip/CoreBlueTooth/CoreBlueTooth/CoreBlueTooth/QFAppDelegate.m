//
//  QFAppDelegate.m
//  CoreBlueTooth
//
//  Created by YG on 15/3/11.
//  Copyright (c) 2015年 YG. All rights reserved.
//

#import "QFAppDelegate.h"
#import "ViewController.h"

@implementation QFAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];

    ViewController * vc=[[ViewController alloc] init];
    UINavigationController * nav = [[UINavigationController alloc] initWithRootViewController:vc];
    nav.navigationBar.translucent = NO;
    
    self.window.rootViewController= nav;
    
    return YES;
}

@end
